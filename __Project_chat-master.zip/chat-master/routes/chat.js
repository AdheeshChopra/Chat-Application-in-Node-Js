exports.main = function(req, res){
  res.render('chat', { "title" : "Chat Sample" });
};
